from django.shortcuts import render,redirect
from django.views.generic import CreateView,FormView
from.models import CustUser
from django.urls import reverse_lazy
from.forms import RegForm,LoginForm
from django.contrib.auth import authenticate,login
# Create your views here.

class LogView(FormView):
    template_name="login.html"
    form_class=LoginForm
    def post(self,req,*args, **kwargs):
        form_data=self.form_class(data=req.POST)
        if form_data.is_valid():
            un=form_data.cleaned_data.get("username")
            ps=form_data.cleaned_data.get("password")
            user=authenticate(req,username=un,password=ps)
            if user:
                if user.is_superuser==1:
                    return redirect("admin")
                else:
                    if user.usertype=="Customer":
                        login(req,user)
                        return redirect("cust")
                    elif user.usertype=="Store":
                        login(req,user)
                        return redirect("store")
            else:
                return redirect("log")
    

class RegView (CreateView):
    model = CustUser
    template_name = "reg.html"
    form_class=RegForm
    success_url=reverse_lazy("log")

