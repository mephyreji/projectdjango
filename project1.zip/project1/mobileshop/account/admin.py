from django.contrib import admin
from.models import CustUser

# Register your models here.
admin.site.register(CustUser)
