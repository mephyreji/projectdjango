from django.urls import path
from.views import StoreHome
urlpatterns = [
    path("store/",StoreHome.as_view(),name="store") 
    
]
