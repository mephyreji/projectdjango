from django.urls import path
from.views import CustHome
urlpatterns = [
    path("cust/",CustHome.as_view(),name="cust") 
    
]
